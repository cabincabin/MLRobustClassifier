
import trainer.model as model

if __name__== "__main__":
    model.GCPPath(True)
    model.getImageGCPPaths()
